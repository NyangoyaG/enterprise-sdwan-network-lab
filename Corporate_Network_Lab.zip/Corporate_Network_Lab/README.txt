Project: 'Corporate_Network_Lab' created on 2026-10-01
Author: Geofrey Nyangoya <nyangoyagb@gmail.com>

Enterprise SD-WAN Network Lab simulating a secure and redundant enterprise network with dual ISP connectivity, FortiGate SD-WAN, MikroTik core routing, VLAN segmentation, Internet failover, SLA health monitoring, NAT, and end-to-end connectivity testing. The project demonstrates primary and backup ISP operation, automatic failover, recovery, packet capture, and network troubleshooting using GNS3.